import test from "node:test";
import assert from "node:assert/strict";

import { defineProjectStateSnapshotSchema } from "../src/core/project-state-snapshot-schema.js";

test("project state snapshot schema returns canonical snapshot with state and graph versions", () => {
  const { projectStateSnapshot } = defineProjectStateSnapshotSchema({
    projectState: {
      projectId: "project-1",
      workspaceId: "workspace-1",
      workspaceArea: "development-workspace",
      workspaceVisibility: "private",
      stateVersion: 3,
      lifecyclePhase: "execution",
      hasArtifacts: true,
      hasBlockers: true,
      approvalStatus: "pending",
      updatedAt: "2025-01-01T10:00:00.000Z",
    },
    executionGraph: {
      nodes: [
        { id: "task-1", status: "done" },
        { id: "task-2", status: "running" },
        { id: "task-3", status: "blocked" },
      ],
      edges: [{ from: "task-1", to: "task-2" }],
    },
  });

  assert.equal(projectStateSnapshot.projectId, "project-1");
  assert.equal(projectStateSnapshot.stateVersion, 3);
  assert.equal(projectStateSnapshot.executionGraphVersion, 4);
  assert.equal(projectStateSnapshot.workspaceReference.workspaceId, "workspace-1");
  assert.equal(projectStateSnapshot.restoreMetadata.requiresApproval, true);
  assert.equal(projectStateSnapshot.artifactSummary.artifactCount, 0);
  assert.equal(projectStateSnapshot.executionGraphSummary.runningNodes, 1);
  assert.equal(projectStateSnapshot.executionGraphSummary.blockedNodes, 1);
});

test("project state snapshot schema falls back safely", () => {
  const { projectStateSnapshot } = defineProjectStateSnapshotSchema();

  assert.equal(typeof projectStateSnapshot.snapshotId, "string");
  assert.equal(typeof projectStateSnapshot.stateVersion, "number");
  assert.equal(Array.isArray(projectStateSnapshot.restoreMetadata.restoreScope), true);
  assert.equal(typeof projectStateSnapshot.summary.isRestorable, "boolean");
});
